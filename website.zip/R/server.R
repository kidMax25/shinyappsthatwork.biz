library(shiny)

# The file names you used are correct
home_html_template <- readLines("app/index_content.html")
gallery_html_template <- readLines("app/gallery.html")

render_home_content <- function(page_name) {
  # 1. Replace Gallery link
  home_content <- gsub('href="gallery.html"', 'href="#" onclick="setPage(\'gallery\'); return false;"', home_html_template)
  
  # 2. Replace Home link
  home_content <- gsub('href="index.html"', 'href="#" onclick="setPage(\'home\'); return false;"', home_content)
  
  # 3. Replace Contact link (needs to trigger a page refresh and scroll)
  # The original link uses a #contact anchor, we replace it to call setPage('contact')
  home_content <- gsub('href="#contact"', 'href="#" onclick="setPage(\'contact\'); return false;"', home_content) 
  
  contact_scroll_script <- ''
  if (page_name == "contact") {
    # If the page state is 'contact', inject a script to scroll the page down after rendering
    contact_scroll_script <- '
      <script>
        // Use a slight delay to ensure the content is fully rendered before scrolling
        setTimeout(function() {
          const contactSection = document.getElementById("contact");
          if (contactSection) {
            contactSection.scrollIntoView({ behavior: "smooth" });
          }
        }, 50);
      </script>
    '
  }
  
  return(
    # Combine the HTML content and the optional scroll script
    shiny::HTML(paste(home_content, contact_scroll_script, collapse = "\n"))
  )
}

render_gallery_content <- function() {
  # The gallery links are already updated in the HTML file, so we just return the content
  return(
    shiny::HTML(paste(gallery_html_template, collapse = "\n"))
  )
}


server <- function(input, output, session) {
  
  # Initial URL query check (sets ?page=home if nothing is set)
  observe({
    query <- parseQueryString(session$clientData$url_search)
    if (is.null(query$page)) {
      updateQueryString("?page=home", session)
    }
  })
  
  # Reactive value that tracks the current page state
  current_page <- reactive({
    query <- parseQueryString(session$clientData$url_search)
    # Get the page from the JS input first, then URL query, default to "home"
    page <- input$page_update %OR% query$page %OR% "home"
    return(page)
  })
  
  # Update URL whenever a page change is triggered by the JS
  observeEvent(input$page_update, {
    updateQueryString(paste0("?page=", input$page_update), session, replace = TRUE)
  })
  
  # Dynamically render the content into the uiOutput("main_content")
  output$main_content <- renderUI({
    page <- current_page()
    if (page == "gallery") {
      return(render_gallery_content())
    } else {
      # Handles both 'home' and 'contact'
      return(render_home_content(page))
    }
  })
  
  # Keep these as placeholders if they were in your original app, though they may not be necessary now.
  output$gallery <- renderUI({})
  output$home <- renderUI({})
}