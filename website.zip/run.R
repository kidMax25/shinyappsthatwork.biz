# ShinyX App Runner
# Hot reload enabled - changes to server.R and HTML will auto-refresh

library(shiny)

# Enable auto-reload
options(shiny.autoreload = TRUE)

# Read HTML template
ui <- htmlTemplate("app/index.html")

# Source server
source("R/server.R")

# Run app
shinyApp(ui = ui, server = server)
